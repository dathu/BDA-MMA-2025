# audioDataAugmentationTutorial
Repository hosting code and slides of the [Audio Data Augmentation series](https://www.youtube.com/watch?v=HH_h52I_Qeg&list=PL-wATfeyAMNoR4aqS-Fv0GRmS6bx5RtTW) on The Sound of AI YT channel.
